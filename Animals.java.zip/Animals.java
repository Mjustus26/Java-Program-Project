/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;
import javax.swing.JOptionPane;
/**
 *
 * @author mikayla
 */
public class Animals {
    
    private String name;
    private String age;
    private String healthConcerns; 
    private String feedingSchedule;
    private String type;

    private Boolean badHealth = false;
    private Boolean badFeed = false; 
    
    public Animals(String data) {
        String[] parts = data.split("\n");
        type = parts[0].split("-")[1].trim();
        name = parts[1].split(":")[1].trim();
        age = parts[2].split(":")[1].trim();
        healthConcerns = parts[3].split(":")[1].trim();
        feedingSchedule = parts[4].split(":")[1].trim();
        
     
        
        if (parts[3].contains("*****")) {
            badHealth = true;
        }
        
        if (parts[4].contains("*****")) {
            badFeed = true;
        } 
   
    }
    //constructor for type
    
    public String getType() {
        return type;
    }
    //constructor for name    
    
    
    public String getName() {
        return name;
    }
    //constructor for age
    
    public String getAge() {
        return age;
    }
    //constructor for healthConcerns
    
    public String getHealthConcerns () {
        return healthConcerns;
    }
    //constructor for feedingschedule
    
    public String getFeedingSchedule() {
        return feedingSchedule; 
    }
    
    
    
    
    public String toString() {
    
    
    if (badHealth) {
        //for dialog box
        JOptionPane.showMessageDialog(null, "Check health concers: \n" + healthConcerns);
    }
    
    if (badFeed) {
        // for dialog box
        JOptionPane.showMessageDialog(null, "Check feeding schedule " + feedingSchedule);
    }
    
    return "Type: " + type + ", \n" +
           "Name: " + name + ", \n" +
            "Age: " + age + ", \n" +
            "Health Concerns: " + healthConcerns + ", \n" +
            "Feeding Schedule: " + feedingSchedule;
    }
    
}
    
    
    

    
