/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package finalproject;

import java.lang.String;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author mikayla
 */
public class FinalProject {
 /**
 * @param args the command line arguments
 */
    public static void main(String[] args) throws IOException  {
        FileInputStream fileByteStream = null;
        Scanner inFS = null;
        String textFile = "";
        String textFile2 = "";
        String userInput = "";

        

        
        fileByteStream = new FileInputStream("animals.txt");
        inFS = new Scanner(fileByteStream);
        
        
        
        
    
        Scanner scnr = new Scanner(System.in);
    
        System.out.println("Would you like to monitor an animal, habitat, or exit?");
        userInput = scnr.nextLine();
     
     
    if (userInput.equals("animal")) {    
        boolean noMoreLines = false;

        while (!noMoreLines) {
            if (!inFS.hasNextLine()) {
                noMoreLines = true;
                break;
            }
            String line = inFS.nextLine() + "\n";
            textFile = textFile + line;

        }
        String[] lines = textFile.split("\n");
        String[] sections = new String[5];
        String section = "";
        int sectionIndex = 0;

        for (String line : lines) {
            if (line.equals("")) {
                sections[sectionIndex] = section;
                section = "";
                sectionIndex++;
            } else {
                section = section + line + "\n";
            }
        }
        sections[sectionIndex] = section;

        String choice = "";
        Scanner input = new Scanner(System.in);

        Animals[] animals = new Animals[4];
        for (int i = 1; i < sections.length; i++) {
            animals[i - 1] = new Animals(sections[i]);
        }
        System.out.println("These are the current animal options: \n" + sections[0]);
        System.out.println("Pick: Lion, Tiger, Bear, Giraffe");
        choice = input.nextLine();

        for (Animals animal : animals) {
            if (choice.toLowerCase().equals(animal.getType().toLowerCase())) {
                System.out.println("Animals\n" + animal.toString());
                System.out.println("\n");
            }
        }

        return;

       //if user enters habitat
        }
    
    
    
    else if (userInput.equals("habitat")) {
        fileByteStream = new FileInputStream("habitats.txt");
        inFS = new Scanner(fileByteStream);
       
    boolean noMoreLines2 = false;
    

        while (!noMoreLines2) {
            if (!inFS.hasNextLine()) {
                noMoreLines2 = true;
                break;
            }
            String line2 = inFS.nextLine() + "\n";
            textFile2 = textFile2 + line2;

        }
        String[] lines2 = textFile2.split("\n");
        String[] sections2 = new String[4];
        String section2 = "";
        int sectionIndexTwo = 0;

        for (String line2 : lines2) {
            if (line2.equals("")) {
                sections2[sectionIndexTwo] = section2;
                section2 = "";
                sectionIndexTwo++;
            } else {
                section2 = section2 + line2 + "\n";
            }
        }
        sections2[sectionIndexTwo] = section2;

        String choice2 = "";
        Scanner input2 = new Scanner(System.in);

        Habitats[] habitats = new Habitats[3];
        for (int a = 1; a < sections2.length; a++) {
            habitats[a - 1] = new Habitats(sections2[a]);
        }
        System.out.println("These are the current habitat options: \n" + sections2[0]);
        System.out.println("Pick: Penguin habitat, Bird house, aquarium");
        choice2 = input2.nextLine();

        for (Habitats habitat : habitats) {
            if (choice2.toLowerCase().equals(habitat.getHabitat().toLowerCase())) {
                System.out.println("Habitats\n" + habitat.toString1());
                System.out.println("\n");
            }
        }

        return;

        
        
        
    }
    
    
    
    
    
    
    
   return; 
    
    }
}
    
