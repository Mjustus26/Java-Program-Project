/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;
import javax.swing.JOptionPane;

/**
 *
 * @author mikayla
 */
public class Habitats {
    
    private String habitat;
    private String temperature;
    private String foodSource;
    private String cleanliness;
  
    private Boolean notClean = false;
    private Boolean badFoodSource = false; 
    
    public Habitats(String data1) {
        String[] partsOne = data1.split("\n");
        habitat = partsOne[0].split("-")[1].trim();
        temperature = partsOne[1].split(":")[1].trim();
        foodSource = partsOne[2].split(":")[1].trim();
        cleanliness = partsOne[3].split(":")[1].trim(); 
   
        
    if (partsOne[1].contains("*****")) {
            notClean = true;
        }
        
    if (partsOne[3].contains("*****")) {
            badFoodSource = true;
        }
    }
      
    public String getHabitat() {
        return habitat;
    }
    public String getTemperature() {
        return temperature;
    }
    public String getFoodSource() {
        return foodSource;
    }
    public String getCleanliness() {
        return cleanliness;
    }
  
    
    public String toString1() {
    
    
    if (notClean) {
        //for dialog box
        JOptionPane.showMessageDialog(null, "Check cleanliness: \n" + cleanliness);
    }
    
    if (badFoodSource) {
        // for dialog box
        JOptionPane.showMessageDialog(null, "Check feeding schedule " + foodSource);
    }
    
    return "Animal Habitat: " + habitat + ", \n" +
           "Temperature: " + temperature + ", \n" +
            "Food Source: " + foodSource + ", \n" +
            "Health Concerns: " + notClean;
            
        }
    
   
  }  

    
